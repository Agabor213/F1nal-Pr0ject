#import <Cocoa/Cocoa.h>

OSType OSTypeFromNSString(NSString *string);
NSString * NSStringFromOSType(OSType fourCharCode);